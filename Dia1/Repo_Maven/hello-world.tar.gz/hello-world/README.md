## CI Jenkins + Maven

Simple Maven Project


